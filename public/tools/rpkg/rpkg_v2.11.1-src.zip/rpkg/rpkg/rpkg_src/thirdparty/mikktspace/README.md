# MikkTSpace
A common standard for tangent space used in baking tools to produce normal maps.

More information can be found at http://www.mikktspace.com/.
