﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace rpkg
{
    public class UserSettings
    {
        public string InputFolder { get; set; }
        public string OutputFolder { get; set; }
        public string ColorTheme { get; set; }
    }
}
