#include "global.h"

void* p_ResourceMemory;

std::stringstream s_Stream;

std::string s_ResponseString = "";