#pragma once
#include <sstream>

extern void* p_ResourceMemory;

extern std::stringstream s_Stream;

extern std::string s_ResponseString;