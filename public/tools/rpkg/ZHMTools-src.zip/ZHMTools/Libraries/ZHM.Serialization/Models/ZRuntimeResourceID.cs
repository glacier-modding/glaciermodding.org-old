﻿namespace ZHM.Serialization.Models
{
    public struct ZRuntimeResourceID
    {
        public ulong Id;
    }
}
