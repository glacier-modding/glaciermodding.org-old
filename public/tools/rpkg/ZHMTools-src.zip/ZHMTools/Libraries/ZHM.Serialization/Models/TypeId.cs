﻿namespace ZHM.Serialization.Models
{
    public struct TypeId
    {
        public uint Index;
        public int Unk;
        public string Name;
    }
}
