#pragma once
#include <string>

extern void revorb(std::string ogg_file);