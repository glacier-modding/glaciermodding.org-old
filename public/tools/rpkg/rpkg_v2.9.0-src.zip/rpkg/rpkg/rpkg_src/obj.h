#pragma once
#include "global.h"

class obj
{
public:
    static void output_to_single_file(asset3ds asset3ds_data, std::string& file_path);
};
