#include "hash.h"

hash::hash()
{

}