#pragma once

#undef ZHM_TARGET
#define ZHM_TARGET 2

#include "ResourceLib.h"