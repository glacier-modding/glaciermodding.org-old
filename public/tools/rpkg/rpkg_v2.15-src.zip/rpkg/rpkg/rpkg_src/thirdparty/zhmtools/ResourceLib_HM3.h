#pragma once

#undef ZHM_TARGET
#define ZHM_TARGET 3

#include "ResourceLib.h"